import sqlite3

def roomnumread(name):
        con = sqlite3.connect('userdate.db')
        cur = con.cursor()
        n = "select 房间号 from reserved where 客户姓名=?"
        cur.execute(n, (name[0],))
        a = cur.fetchall()
        con.commit()
        con.close()
        return a

def customerregister(data):#name, roomnum)
        con = sqlite3.connect('userdate.db')
        cur = con.cursor()
        n = "select * from reserved where 客户姓名=? and 房间号=?"
        cur.execute(n, (data[0],data[1]))
        a = cur.fetchall()
        m ="select 单价 from room where 房间号=?"
        cur.execute(m, (data[1],))
        b = cur.fetchall()
        o ="insert into income values(?,?,?,?)"
        cur.execute(o, (a[0][0], a[0][1], a[0][2],b[0][0]))
        con.commit()
        con.close()
        fin=[a,b]
        return fin

def summoney(data):#name,roomnum
        con = sqlite3.connect('userdate.db')
        cur = con.cursor()
        n = "select sum(房间价格) from income"
        cur.execute(n)
        a = cur.fetchall()
        # 房间号变为可用
        m = 'update room set 有无=? where 房间号=?'
        cur.execute(m, ('有', data[1]))
        # 删除客户预定
        o = "delete from reserved where 房间号=?"
        cur.execute(o, (data[1],))
        # 删除登记的客户
        q= 'select count(?) from reserved'
        cur.execute(q, (data[0],))
        b=cur.fetchall()
        if int(b[0][0])==1:
         p = "delete from customer where 姓名=? "
         cur.execute(p, (data[0],))
        con.commit()
        con.close()
        return a[0][0]

def harvest(kong):
        con = sqlite3.connect('userdate.db')
        cur = con.cursor()
        n = "select sum(房间价格) from income"
        cur.execute(n)
        a = cur.fetchall()
        fin=[a]
        return fin

def Unsubscribe(data):   #撤销，退订  name,roomnum
        con = sqlite3.connect('userdate.db')
        cur = con.cursor()
        o = "delete from income where 客户=? and 房间号=?"
        cur.execute(o, (data[0],data[1]))
        con.commit()
        con.close()