import sqlite3


def cusshow(kong):
    con = sqlite3.connect('userdate.db')
    cur = con.cursor()
    n = "select * from customer"
    cur.execute(n)
    a = cur.fetchall()
    con.commit()
    con.close()
    return a


def cusinput(data):  #name,sex,phone,id
    con = sqlite3.connect('userdate.db')
    cur = con.cursor()
    n = "insert into customer values(?,?,?,?)"
    cur.execute(n, (data))
    con.commit()
    con.close()


def cusdelone(name):
    con = sqlite3.connect('userdate.db')
    cur = con.cursor()
    n = "delete from customer where 姓名=?"
    cur.execute(n, (name[0],))
    con.commit()
    con.close()


def cusdelall(kong):
    con = sqlite3.connect('userdate.db')
    cur = con.cursor()
    n = "delete from customer"
    cur.execute(n)
    con.commit()
    con.close()


def cussearch(data):  #name,sex,phone,id
    con = sqlite3.connect('userdate.db')
    cur = con.cursor()
    if data[0] == '?':
        data[0] = ''
    if data[2] == '?':
        data[2] = ''
    if data[3] == '?':
        data[3] = ''
    if data[1] == '?':
        data[1] = ''
    n = "select * from customer where (姓名=? or ?='') and (性别=? or ?='') and (联系方式=? or ?='') and (身份证号码=? or ?='')"
    cur.execute(n, (data[0], data[0], data[1], data[1], data[2], data[2], data[3], data[3]))
    a = cur.fetchall()
    con.commit()
    con.close()
    return a

def customeryw(name):
    choice = 1
    con = sqlite3.connect('userdate.db')
    cur = con.cursor()
    q = 'select 姓名 from customer'
    cur.execute(q)
    b = cur.fetchall()
    for i in range(len(b)):
        if str(b[i][0]) == str(name[0]):
            choice = 0
    fin=[choice]
    return fin
