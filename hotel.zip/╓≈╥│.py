import sys
from hotel import entersql
from hotel.qt页面 import menu, changepassword, customer, entersys, reserve, roomadd,income
from PyQt5 import QtCore
from client import request
from incomesql import roomnumread,customerregister,summoney,Unsubscribe,harvest
from  hotel.entersql import enter1,changewd
from reservesql import roomnum,customeread,register,reshow,resdelone,resroomyw
from hotel.customersql import cusshow,cusinput,cusdelone,cussearch,cusdelall,customeryw
from hotel.roomaddsql import roomshow,roominput,roomdelone,roomdelall,roomsearch
from PyQt5.QtWidgets import QApplication, QMainWindow, QMessageBox,QTableWidgetItem

class Mywindow0(QMainWindow, changepassword.Ui_MainWindow):#修改密码
    def __init__(self):
        super(Mywindow0, self).__init__()
        self.setupUi(self)  # 继承于Ui_MainWindow
        self.pushButton.clicked.connect(self.ButtonFunction)
    def ButtonFunction(self):
        a = self.lineEdit.text()
        b = self.lineEdit_2.text()
        c = self.lineEdit_3.text()
        choice = request('enter1', a,b)  #entersql.enter1(a, b)
        if int(choice) == 1:
            request('changewd',c,a)  #entersql.changewd(c, a)
            reply = QMessageBox.question(self, '完成', '修改成功！！！( =v=)', QMessageBox.Yes | QMessageBox.No,QMessageBox.No)
        if int(choice) == 0:
           reply = QMessageBox.question(self, '错误', '就你想改密码？？？( =A=)', QMessageBox.Yes | QMessageBox.No, QMessageBox.No)

class Mywindow1(QMainWindow, entersys.Ui_MainWindow):#登入
    def __init__(self):
        super(Mywindow1, self).__init__()
        self.setupUi(self)  # 继承于Ui_MainWindow
        self.pushButton.clicked.connect(self.ButtonFunction)
        self.pushButton_2.clicked.connect(self.ButtonFunction_2)   #修改密码

    def closeEvent(self, event):    #退出提示
      reply = QMessageBox.question(self, '退出', '你确定要退出华航酒店系统吗？╥﹏╥...', QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
      if reply == QMessageBox.Yes:
        event.accept()
      else:
        event.ignore()
    def ButtonFunction(self):
        a = self.lineEdit.text()
        b = self.lineEdit_2.text()
        choice = request('enter1',a, b)#entersql.enter1(a, b)  #entersql.
        if int(choice) == 1:
           self.Mywindow2=Mywindow2()
           self.Mywindow2.show()
        if int(choice) == 0:
           reply = QMessageBox.question(self, '错误', '管理员账号或密码输入错误，请重新输入( ╯▽╰)', QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
    def ButtonFunction_2(self):
        self.Mywindow0 = Mywindow0()
        self.Mywindow0.show()

class Mywindow2(QMainWindow, menu.Ui_MainWindow):#主菜单
    def __init__(self):
        super(Mywindow2, self).__init__()
        self.setupUi(self)  # 继承于Ui_MainWindow
        self.pushButton.clicked.connect(self.ButtonFunction1)   #客房管理
        self.pushButton_2.clicked.connect(self.ButtonFunction2) #客户管理
        self.pushButton_3.clicked.connect(self.ButtonFunction3) #预定管理
        self.pushButton_4.clicked.connect(self.ButtonFunction4) #退房管理
    def ButtonFunction1(self):
        self.Mywindow3 = Mywindow3()
        self.Mywindow3.show()
    def ButtonFunction2(self):
        self.Mywindow4 = Mywindow4()
        self.Mywindow4.show()
    def ButtonFunction3(self):
        self.Mywindow5 = Mywindow5()
        self.Mywindow5.show()
    def ButtonFunction4(self):
        self.Mywindow6 = Mywindow6()
        self.Mywindow6.show()

class Mywindow3(QMainWindow, roomadd.Ui_MainWindow):#客房管理
    def __init__(self):
        super(Mywindow3, self).__init__()
        self.setupUi(self)  # 继承于Ui_MainWindow
        data=request('roomshow','') #roomshow()
        num=len(data)
        for i in range(int(num)):
            self.tableWidget.insertRow(i)
            item_roomtype  = QTableWidgetItem(data[i][0])
            item_roomprice = QTableWidgetItem(str(data[i][1]))
            item_roomnum   = QTableWidgetItem(str(data[i][2]))
            item_roomyw    = QTableWidgetItem(str(data[i][3]))
            self.tableWidget.setItem(i, 0, item_roomnum)
            self.tableWidget.setItem(i, 1, item_roomtype)
            self.tableWidget.setItem(i, 2, item_roomprice)
            self.tableWidget.setItem(i, 3, item_roomyw)

        self.pushButton.clicked.connect(self.ButtonFunction)      # 添加
        self.pushButton_4.clicked.connect(self.DeleteFunction)    # 清空
        self.pushButton_3.clicked.connect(self.DeleteoneFunction) # 删除所选行
        self.pushButton_2.clicked.connect(self.SearchFunction)    #查询
        self.pushButton_5.clicked.connect(self.returnFunction)    # 还原
        self.pushButton_6.clicked.connect(self.ChangeFunction)    #修改
        self.tableWidget.clicked.connect(self.tableclicked)       #一键填充

        
    def ButtonFunction(self):#添加
        choice=0
        roomnum   = QTableWidgetItem(self.lineEdit.text())
        roomtype  = QTableWidgetItem(self.comboBox.currentText())
        roomprice = QTableWidgetItem(self.lineEdit_2.text())
        rommyw    = QTableWidgetItem(self.comboBox_2.currentText())
        data=request('roomshow','') #roomshow()
        num=len(data)
        for i in range(int(num)):
            if int(self.lineEdit.text())==int(data[i][2]):
                reply = QMessageBox.question(self, '错误', '已存在该房间号( =A=)', QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
                choice=1
        if int(choice)==0:
            request('roominput',self.lineEdit.text(),self.comboBox.currentText(),self.lineEdit_2.text(),self.comboBox_2.currentText())  #roominput(self.lineEdit.text(),self.comboBox.currentText(),self.lineEdit_2.text(),self.comboBox_2.currentText())
            rowlength = self.tableWidget.rowCount()
            self.tableWidget.insertRow(rowlength)
            self.tableWidget.setItem(rowlength, 0, roomnum)
            self.tableWidget.setItem(rowlength, 1, roomtype)
            self.tableWidget.setItem(rowlength, 2, roomprice)
            self.tableWidget.setItem(rowlength, 3, rommyw)

    def tableclicked(self):
        self.lineEdit.setText(self.tableWidget.item(self.tableWidget.currentIndex().row(), 0).text())
        self.lineEdit_2.setText(self.tableWidget.item(self.tableWidget.currentIndex().row(), 2).text())
        self.comboBox.setCurrentText(self.tableWidget.item(self.tableWidget.currentIndex().row(), 1).text())
        self.comboBox_2.setCurrentText(self.tableWidget.item(self.tableWidget.currentIndex().row(), 3).text())

    def DeleteFunction(self):  # 清空
        rowlength = self.tableWidget.rowCount()  # 表中的行数
        for i in range(0, rowlength):
            self.tableWidget.removeRow(0)
        request('roomdelall','')   #roomdelall()

    def DeleteoneFunction(self):  # 删除所选行
        row_index = self.tableWidget.currentIndex().row()
        current_row_name = self.tableWidget.item(row_index, 0).text()
        self.tableWidget.removeRow(self.tableWidget.currentIndex().row())
        request('roomdelone',current_row_name)       #roomdelone(current_row_name)

    def SearchFunction(self):
        rowlength = self.tableWidget.rowCount()  # 表中的行数
        for i in range(0, rowlength):
            self.tableWidget.removeRow(0)
        roomnum   = self.lineEdit.text()
        roomtype  = self.comboBox.currentText()
        roomprice = self.lineEdit_2.text()
        rommyw    = self.comboBox_2.currentText()
        data=request('roomsearch',roomnum,roomtype,roomprice,rommyw)              #roomsearch(roomnum,roomtype,roomprice,rommyw)
        num=len(data)
        rowlength = self.tableWidget.rowCount()  # 表中的行数
        for i in range(0, rowlength):
            self.tableWidget.removeRow(0)
        for i in range(int(num)):
            self.tableWidget.insertRow(i)
            item_roomtype  = QTableWidgetItem(data[i][0])
            item_roomprice = QTableWidgetItem(str(data[i][1]))
            item_roomnum   = QTableWidgetItem(str(data[i][2]))
            item_roomyw    = QTableWidgetItem(str(data[i][3]))
            self.tableWidget.setItem(i, 0, item_roomnum)
            self.tableWidget.setItem(i, 1, item_roomtype)
            self.tableWidget.setItem(i, 2, item_roomprice)
            self.tableWidget.setItem(i, 3, item_roomyw)

    def returnFunction(self):
        rowlength = self.tableWidget.rowCount()  # 表中的行数
        for i in range(0, rowlength):
            self.tableWidget.removeRow(0)
        data = request('roomshow','')   #roomshow()
        num = len(data)
        for i in range(int(num)):
            self.tableWidget.insertRow(i)
            item_roomtype = QTableWidgetItem(data[i][0])
            item_roomprice = QTableWidgetItem(str(data[i][1]))
            item_roomnum = QTableWidgetItem(str(data[i][2]))
            item_roomyw = QTableWidgetItem(str(data[i][3]))
            self.tableWidget.setItem(i, 0, item_roomnum)
            self.tableWidget.setItem(i, 1, item_roomtype)
            self.tableWidget.setItem(i, 2, item_roomprice)
            self.tableWidget.setItem(i, 3, item_roomyw)

    def ChangeFunction(self):
        row_index = self.tableWidget.currentIndex().row()
        current_row_name = self.tableWidget.item(row_index, 0).text()
        roomnum   = self.lineEdit.text()
        roomtype  = self.comboBox.currentText()
        roomprice = self.lineEdit_2.text()
        roomyw    = self.comboBox_2.currentText()
        request('roomdelone',current_row_name)    #roomdelone(current_row_name)
        request('roominput',self.lineEdit.text(), self.comboBox.currentText(), self.lineEdit_2.text(), self.comboBox_2.currentText())                                              #roominput(self.lineEdit.text(), self.comboBox.currentText(), self.lineEdit_2.text(), self.comboBox_2.currentText())
        rowlength = row_index
        self.tableWidget.setItem(rowlength, 0, QTableWidgetItem(roomnum))
        self.tableWidget.setItem(rowlength, 1, QTableWidgetItem(roomtype))
        self.tableWidget.setItem(rowlength, 2, QTableWidgetItem(roomprice))
        self.tableWidget.setItem(rowlength, 3, QTableWidgetItem(roomyw))

class Mywindow4(QMainWindow, customer.Ui_MainWindow):#客户登记等
    def __init__(self):
        super(Mywindow4, self).__init__()
        self.setupUi(self)  # 继承于Ui_MainWindow
        data= request('cusshow','')         #cusshow()
        num=len(data)
        for i in range(int(num)):
            self.tableWidget.insertRow(i)
            item_name   = QTableWidgetItem(data[i][0])
            item_sex    = QTableWidgetItem(str(data[i][1]))
            item_phone  = QTableWidgetItem(str(data[i][2]))
            item_id     = QTableWidgetItem(str(data[i][3]))
            self.tableWidget.setItem(i, 0, item_name)
            self.tableWidget.setItem(i, 1, item_sex)
            self.tableWidget.setItem(i, 2, item_phone)
            self.tableWidget.setItem(i, 3, item_id)

        self.pushButton.clicked.connect(self.ButtonFunction) # 添加
        self.pushButton_4.clicked.connect(self.DeleteoneFunction) # 删除所选行
        self.pushButton_2.clicked.connect(self.SearchFunction) #查询
        self.pushButton_3.clicked.connect(self.ChangeFunction) #修改
        self.pushButton_6.clicked.connect(self.ReturnFunction)  # 还原
        self.pushButton_5.clicked.connect(self.DeleteFunction) #清空
        self.tableWidget.clicked.connect(self.tableclicked)  #一键填充

    def ChangeFunction(self):
        row_index = self.tableWidget.currentIndex().row()
        current_row_name = self.tableWidget.item(row_index, 0).text()
        name    = self.lineEdit.text()
        sex     = self.comboBox.currentText()
        phone   = self.lineEdit_3.text()
        id      = self.lineEdit_4.text()
        request('cusdelone',current_row_name)               #cusdelone(current_row_name)
        request('cusinput',self.lineEdit.text(), self.comboBox.currentText(), self.lineEdit_3.text(), self.lineEdit_4.text())                                                            #cusinput(self.lineEdit.text(), self.comboBox.currentText(), self.lineEdit_3.text(), self.lineEdit_4.text())
        rowlength=row_index
        self.tableWidget.setItem(rowlength, 0, QTableWidgetItem(name))
        self.tableWidget.setItem(rowlength, 1, QTableWidgetItem(sex))
        self.tableWidget.setItem(rowlength, 2, QTableWidgetItem(phone))
        self.tableWidget.setItem(rowlength, 3, QTableWidgetItem(id))

    def ButtonFunction(self):#添加
        name  = QTableWidgetItem(self.lineEdit.text())
        sex  = QTableWidgetItem(self.comboBox.currentText())
        phone = QTableWidgetItem(self.lineEdit_3.text())
        id    = QTableWidgetItem(self.lineEdit_4.text())
        choice=request('customeryw',self.lineEdit.text())                #customeryw(self.lineEdit.text())
        if int(choice)==1:
            request('cusinput',self.lineEdit.text(),self.comboBox.currentText(),self.lineEdit_3.text(),self.lineEdit_4.text())                       #cusinput(self.lineEdit.text(),self.comboBox.currentText(),self.lineEdit_3.text(),self.lineEdit_4.text())
            rowlength = self.tableWidget.rowCount()
            self.tableWidget.insertRow(rowlength)
            self.tableWidget.setItem(rowlength, 0, name)
            self.tableWidget.setItem(rowlength, 1, sex)
            self.tableWidget.setItem(rowlength, 2, phone)
            self.tableWidget.setItem(rowlength, 3, id)
        else:
            reply = QMessageBox.question(self, '错误', '该客户已登记=v=',QMessageBox.Yes | QMessageBox.No, QMessageBox.No)

    def DeleteoneFunction(self):  # 删除所选行
        row_index = self.tableWidget.currentIndex().row()
        current_row_name = self.tableWidget.item(row_index, 0).text()
        self.tableWidget.removeRow(self.tableWidget.currentIndex().row())
        request('cusdelone',current_row_name)     #cusdelone(current_row_name)


    def SearchFunction(self):
        name  = self.lineEdit.text()
        sex  = self.comboBox.currentText()
        phone = self.lineEdit_3.text()
        id    = self.lineEdit_4.text()
        data=request('cussearch',name,sex,phone,id)       #cussearch(name,sex,phone,id)
        num = len(data)
        rowlength = self.tableWidget.rowCount()
        for i in range(0, rowlength):
            self.tableWidget.removeRow(0)
        for i in range(int(num)):
            self.tableWidget.insertRow(i)
            item_name = QTableWidgetItem(data[i][0])
            item_sex = QTableWidgetItem(str(data[i][1]))
            item_phone = QTableWidgetItem(str(data[i][2]))
            item_id = QTableWidgetItem(str(data[i][3]))
            self.tableWidget.setItem(i, 0, item_name)
            self.tableWidget.setItem(i, 1, item_sex)
            self.tableWidget.setItem(i, 2, item_phone)
            self.tableWidget.setItem(i, 3, item_id)

    def ReturnFunction(self):
        rowlength = self.tableWidget.rowCount()  # 表中的行数
        for i in range(0, rowlength):
            self.tableWidget.removeRow(0)
        data = request('cusshow','')            #cusshow()
        num=len(data)
        for i in range(int(num)):
            self.tableWidget.insertRow(i)
            item_name  = QTableWidgetItem(data[i][0])
            item_sex = QTableWidgetItem(str(data[i][1]))
            item_phone   = QTableWidgetItem(str(data[i][2]))
            item_id    = QTableWidgetItem(str(data[i][3]))
            self.tableWidget.setItem(i, 0, item_name)
            self.tableWidget.setItem(i, 1, item_sex)
            self.tableWidget.setItem(i, 2, item_phone)
            self.tableWidget.setItem(i, 3, item_id)

    def DeleteFunction(self):  # 清空
        rowlength = self.tableWidget.rowCount()  # 表中的行数
        for i in range(0, rowlength):
            self.tableWidget.removeRow(0)
        request('cusdelall','')          #cusdelall()

    def tableclicked(self):
        self.lineEdit.setText(self.tableWidget.item(self.tableWidget.currentIndex().row(), 0).text())
        self.lineEdit_3.setText(self.tableWidget.item(self.tableWidget.currentIndex().row(), 2).text())
        self.lineEdit_4.setText(self.tableWidget.item(self.tableWidget.currentIndex().row(), 3).text())
        self.comboBox.setCurrentText(self.tableWidget.item(self.tableWidget.currentIndex().row(), 1).text())

class Mywindow5(QMainWindow, reserve.Ui_MainWindow):#预定管理
    def __init__(self):
        super(Mywindow5, self).__init__()
        self.setupUi(self)  # 继承于Ui_MainWindow
        data= request('reshow','')       #reshow()
        num=len(data)
        for i in range(int(num)):
            self.tableWidget.insertRow(i)
            item_name  = QTableWidgetItem(data[i][0])
            item_roomtype = QTableWidgetItem(str(data[i][1]))
            item_roomnum   = QTableWidgetItem(str(data[i][2]))
            self.tableWidget.setItem(i, 0, item_name)
            self.tableWidget.setItem(i, 1, item_roomtype)
            self.tableWidget.setItem(i, 2, item_roomnum)

        self.pushButton.clicked.connect(self.SearchFunction)   # 查询
        self.pushButton_4.clicked.connect(self.AddFunction)    # 添加
        self.pushButton_5.clicked.connect(self.InputFunction)  # 录入
        self.pushButton_3.clicked.connect(self.DeleteFunction) # 删除
        self.pushButton_2.clicked.connect(self.ChangeFunction) # 修改
        self.tableWidget.clicked.connect(self.tableclicked)    #一键填充

    def SearchFunction(self):
        roomtype = self.comboBox_2.currentText()
        sex=self.comboBox_4.currentText()
        b=request('roomnum',roomtype)      # roomnum(roomtype)
        a=request('customeread',sex)  #customeread(sex)
        num1=len(a)
        num2=len(b)
        self.comboBox_3.clear() #清除上次搜索遗留的选项
        self.comboBox.clear()
        for i in range(num1):
            self.comboBox.addItem(a[i][0])
        for j in range(num2):
            self.comboBox_3.addItem(b[j][0])

    def InputFunction(self):
        self.lineEdit.setText(self.comboBox.currentText())
        self.lineEdit_2.setText(self.comboBox_3.currentText())

    def AddFunction(self):
        name    = self.lineEdit.text()
        roomnum1 = self.lineEdit_2.text()
        roomtype= self.comboBox_2.currentText()
        #判断有无对应类型的房间及房间号，以免未点查询就选了
        choice= request('resroomyw',roomnum1,roomtype)           #resroomyw(roomnum1,roomtype)
        if int(choice)==1:
            request('register',name,roomtype,roomnum1)           #register(name,roomtype,roomnum1)
            name   = QTableWidgetItem(self.lineEdit.text())
            roomtype  = QTableWidgetItem(self.comboBox_2.currentText())
            roomnum = QTableWidgetItem(self.lineEdit_2.text())
            rowlength = self.tableWidget.rowCount()
            self.tableWidget.insertRow(rowlength)
            self.tableWidget.setItem(rowlength, 0, name)
            self.tableWidget.setItem(rowlength, 1, roomtype)
            self.tableWidget.setItem(rowlength, 2, roomnum)
            self.SearchFunction()
        if int(choice)==0:
            reply = QMessageBox.question(self, '错误', '无该类型的房间号( =A=)', QMessageBox.Yes | QMessageBox.No,QMessageBox.No)
        if int(choice)==2:
            reply = QMessageBox.question(self, '错误', '该房间被预定( =A=)', QMessageBox.Yes | QMessageBox.No,QMessageBox.No)

    def DeleteFunction(self):
        row_index = self.tableWidget.currentIndex().row()
        current_row_name = self.tableWidget.item(row_index, 2).text()
        self.tableWidget.removeRow(self.tableWidget.currentIndex().row())
        request('resdelone',current_row_name)          #resdelone(current_row_name)
        self.SearchFunction()

    def ChangeFunction(self):
        row_index = self.tableWidget.currentIndex().row()
        current_row_name = self.tableWidget.item(row_index, 2).text()
        name = self.lineEdit.text()
        roomtype = self.comboBox_2.currentText()
        roomnum = self.lineEdit_2.text()
        #判断有无对应类型的房间及房间号，以免未点查询就选了
        choice=request('resroomyw',roomnum,roomtype)   #resroomyw(roomnum,roomtype)
        if int(choice)==1:
            request('resdelone',current_row_name)                 #resdelone(current_row_name)
            request('register',name, roomtype, roomnum)                #register(name, roomtype, roomnum)
            rowlength = row_index
            self.tableWidget.setItem(rowlength, 0, QTableWidgetItem(name))
            self.tableWidget.setItem(rowlength, 1, QTableWidgetItem(roomtype))
            self.tableWidget.setItem(rowlength, 2, QTableWidgetItem(roomnum))
            self.SearchFunction()
        if int(choice)==0:
            reply = QMessageBox.question(self, '错误', '无该类型的房间号( =A=)', QMessageBox.Yes | QMessageBox.No,QMessageBox.No)
        if int(choice)==2:
            reply = QMessageBox.question(self, '错误', '该房间被预定( =A=)', QMessageBox.Yes | QMessageBox.No,QMessageBox.No)

    def tableclicked(self):
        self.lineEdit.setText(self.tableWidget.item(self.tableWidget.currentIndex().row(), 0).text())
        self.lineEdit_2.setText(self.tableWidget.item(self.tableWidget.currentIndex().row(), 2).text())
        self.comboBox.setCurrentText(self.tableWidget.item(self.tableWidget.currentIndex().row(), 0).text())
        self.comboBox_3.setCurrentText(self.tableWidget.item(self.tableWidget.currentIndex().row(), 2).text())
        self.comboBox_2.setCurrentText(self.tableWidget.item(self.tableWidget.currentIndex().row(), 1).text())

class Mywindow6(QMainWindow, income.Ui_MainWindow):#退房管理
    def __init__(self):
        super(Mywindow6, self).__init__()
        self.setupUi(self)  # 继承于Ui_MainWindow
        money=request('harvest','')  #harvest()
        self.lineEdit_3.setText(str(money))
        self.pushButton_3.clicked.connect(self.SearchFunction) # 搜索
        self.pushButton.clicked.connect(self.RegisterFunction)  # 添加
        self.pushButton_2.clicked.connect(self.MoneyFunction)  # 结算
        self.pushButton_5.clicked.connect(self.ReturnFunction)  # 结算

    def SearchFunction(self):
        name = self.lineEdit.text()
        a=  request('roomnumread',name)                #roomnumread(name)
        num1=len(a)
        self.comboBox_2.clear()
        for i in range(num1):
            self.comboBox_2.addItem(a[i][0])

    def RegisterFunction(self):
        choice=0
        name = self.lineEdit.text()
        roomnum = self.comboBox_2.currentText()
        #判断是否登记过了
        rowlength = self.tableWidget.rowCount()
        for i in range(rowlength):
            if name==self.tableWidget.item(i, 0).text() and roomnum==self.tableWidget.item(i, 2).text():
                choice=1
        if choice==1:
         reply = QMessageBox.question(self, '错误', '该客户及对应房间号已登记Q﹏Q...',QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if choice==0:
            a,b= request('customerregister',name, roomnum)            #customerregister(name, roomnum)
            name = QTableWidgetItem(a[0][0])
            roomtype = QTableWidgetItem(a[0][1])
            roomnum = QTableWidgetItem(a[0][2])
            roomprice= QTableWidgetItem(b[0][0])
            rowlength = self.tableWidget.rowCount()
            self.tableWidget.insertRow(rowlength)
            self.tableWidget.setItem(rowlength, 0, name)
            self.tableWidget.setItem(rowlength, 1, roomtype)
            self.tableWidget.setItem(rowlength, 2, roomnum)
            self.tableWidget.setItem(rowlength, 3, roomprice)


    def MoneyFunction(self):
        rowlength = self.tableWidget.rowCount()
        for i in range(rowlength):
            money=request('summoney',self.tableWidget.item(i, 0).text(),self.tableWidget.item(i, 2).text())         #summoney(self.tableWidget.item(i, 0).text(),self.tableWidget.item(i, 2).text())
        rowlength = self.tableWidget.rowCount()  # 表中的行数
        for i in range(0, rowlength):
            self.tableWidget.removeRow(0)
        self.lineEdit_3.setText(str(money))
        self.SearchFunction()

    def ReturnFunction(self):
        rowlength = self.tableWidget.rowCount()
        for i in range(rowlength):
            request('Unsubscribe',self.tableWidget.item(i, 0).text(),self.tableWidget.item(i, 2).text())              #Unsubscribe(self.tableWidget.item(i, 0).text(),self.tableWidget.item(i, 2).text())
        rowlength = self.tableWidget.rowCount()  # 表中的行数
        for i in range(0, rowlength):
            self.tableWidget.removeRow(0)
        self.SearchFunction()


if __name__ == "__main__":
    QtCore.QCoreApplication.setAttribute(QtCore.Qt.AA_EnableHighDpiScaling)
    app = QApplication(sys.argv)
    window1 = Mywindow1()
    window1.show()
    sys.exit(app.exec_())


