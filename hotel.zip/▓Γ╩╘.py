string = "1"
# 先按照 '#' 分割字符串得到每个子字符串
sub_strings = string.split('#')

# 创建一个空的二维数组
two_dimensional_array = []

# 遍历每个子字符串
for sub_string in sub_strings:
    # 去掉括号并按照逗号分割得到每个元素
    elements = sub_string.strip('()').split(',')

    # 将元素添加到二维数组中
    two_dimensional_array.append(elements)

print(two_dimensional_array)