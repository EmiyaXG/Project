import socket

def changetype1(data):  #数组变字符串
    res=''
    num=len(data)
    for i in range(num):
       if i !=int(num-1):
        res=res+str(data[i])+'#'
       else:
        res=res+str(data[i])
    return res

def changetype2(data):   #字符串变数组
    sub_strings = data.split('#')
    # 创建一个空的二维数组
    asd = []
    # 遍历每个子字符串
    for sub_string in sub_strings:
        # 去掉括号并按照逗号分割得到每个元素
        elements = sub_string.strip('()').split(',')
        # 去掉每个元素中的单引号和空格
        elements = [element.strip().strip("'") for element in elements]
        # 将元素添加到二维数组中
        asd.append(elements)
    return asd

def request(Order,*data):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    data=changetype1(data)
    Order=str(Order)
    sent = sock.sendto(Order.encode('utf-8'), ('127.0.0.1', 2119))
    sent = sock.sendto(data.encode('utf-8'), ('127.0.0.1', 2119))
    data, server = sock.recvfrom(1000)
    data=data.decode()
    # print('修改前',data)
    data=changetype2(data)
    # print(data)   #返回的数据，用于检验
    # print('最终传递值',data)
    return data






