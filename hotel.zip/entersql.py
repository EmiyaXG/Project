import sqlite3

def enter1(data):#name password
    b=0
    con=sqlite3.connect('userdate.db')
    cur=con.cursor()
    n='select * from userdate'
    cur.execute(n)
    a=cur.fetchall()
    name = str(data[0])
    password = str(data[1])
    for i in range(len(a)):
        if name==str(a[i][0]) and password==str(a[i][1]):
            b=1
    con.commit()
    con.close()
    return str(b)


def changewd(data):#name password
    con=sqlite3.connect('userdate.db')
    cur=con.cursor()
    n='update userdate set password=? where username=?'
    cur.execute(n,(data[0],data[1]))
    con.commit()
    con.close()