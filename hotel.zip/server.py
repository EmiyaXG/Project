import socket
from hotel.qt页面 import menu, changepassword, customer, entersys, reserve, roomadd,income
from hotel import entersql
from  hotel.entersql import enter1,changewd
from incomesql import roomnumread,customerregister,summoney,Unsubscribe,harvest
from reservesql import roomnum,customeread,register,reshow,resdelone,resroomyw
from hotel.customersql import cusshow,cusinput,cusdelone,cussearch,cusdelall,customeryw
from hotel.roomaddsql import roomshow,roominput,roomdelone,roomdelall,roomsearch
def changetype(data):
    res=''
    num=len(data)
    for i in range(num):
       if i !=int(num-1):
        res=res+str(data[i])+'#'
       else:
        res=res+str(data[i])
    return res

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind(('127.0.0.1', 2119))
while True:
    data1, address1 = sock.recvfrom(1000)
    data2, address2 = sock.recvfrom(1000)
    data1=data1.decode()
    data2=data2.decode()
    data2=data2.split('#')
    # print(data2[1],data2[0])    #相关数据
    res=locals()[data1](data2)   #调用函数并执行
    if res==None:
        res='执行成功'
        sock.sendto(res.encode('UTF-8'), address1)
    else:
        res=changetype(res)
        # print('要传给客户端的数据',res)
        sock.sendto(res.encode('UTF-8'), address1)

