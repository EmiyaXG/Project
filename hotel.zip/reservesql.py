import sqlite3

def roomnum(roomtype):
    con = sqlite3.connect('userdate.db')
    cur = con.cursor()
    n = "select 房间号 from room where 房型=? and 有无=?"
    cur.execute(n,(roomtype[0],'有'))
    a = cur.fetchall()
    con.commit()
    con.close()
    return a

def customeread(sex):
    con = sqlite3.connect('userdate.db')
    cur = con.cursor()
    n = "select 姓名 from customer where 性别 =? or ?='?' "
    cur.execute(n,(sex[0],sex[0]))
    a = cur.fetchall()
    con.commit()
    con.close()
    return a

def register(data):  #name,roomtype,roomnum
    con=sqlite3.connect('userdate.db')
    cur=con.cursor()
    #信息录入
    n= "insert into reserved values(?,?,?)"
    cur.execute(n,(data[0],data[1],data[2]))
    #房间号变为不可用
    m = 'update room set 有无=? where 房间号=?'
    cur.execute(m, ('无',data[2]))
    con.commit()
    con.close()

def reshow(kong):   #空
    con = sqlite3.connect('userdate.db')
    cur = con.cursor()
    n = "select * from reserved"
    cur.execute(n)
    a = cur.fetchall()
    con.commit()
    con.close()
    return a

def resdelone(roomnum):
    con = sqlite3.connect('userdate.db')
    cur = con.cursor()
    n = "delete from reserved where 房间号=?"
    cur.execute(n, (roomnum[0],))
    m = 'update room set 有无=? where 房间号=?'
    cur.execute(m, ('有',roomnum[0]))
    con.commit()
    con.close()

def resroomyw(data): #roomnum,roomtype
    choice=0
    con = sqlite3.connect('userdate.db')
    cur = con.cursor()
    #判断房间号和房型是否匹配
    n = "select 房型,房间号 from room"
    cur.execute(n)
    a = cur.fetchall()
    num=len(a)
    for i in range(num):
        if str(a[i][0])==str(data[1]) and int(a[i][1])==int(data[0]):
            choice=1
    #判断房间是否可用
    m= 'select 房间号,有无 from room'
    cur.execute(m)
    b = cur.fetchall()
    num=len(b)
    for j in range(num):
        if str(b[j][0])==str(data[0]) and str(b[j][1])=='无':
            choice=2
    con.commit()
    con.close()
    fin=[]
    fin.append(choice)
    return fin