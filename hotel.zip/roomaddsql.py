import sqlite3

def roomshow(kong):
    con=sqlite3.connect('userdate.db')
    cur=con.cursor()
    n= "select * from room"
    cur.execute(n)
    a=cur.fetchall()
    print('roomaddsql ',a)
    con.commit()
    con.close()
    return a

def roominput(data):  #roomnum,roomtype,roomprice,roomyw
    con=sqlite3.connect('userdate.db')
    cur=con.cursor()
    n= "insert into room values(?,?,?,?) "
    cur.execute(n,(data[1],data[2],data[0],data[3]))
    con.commit()
    con.close()

def roomdelone(room):
    con = sqlite3.connect('userdate.db')
    cur = con.cursor()
    n = "delete from room where 房间号=?"
    cur.execute(n, (room[0],))
    con.commit()
    con.close()

def roomdelall(kong):
    con = sqlite3.connect('userdate.db')
    cur = con.cursor()
    n = "delete from room"
    cur.execute(n)
    con.commit()
    con.close()

def roomsearch(data):#roomnum,roomtype,roomprice,roomyw
    con = sqlite3.connect('userdate.db')
    cur = con.cursor()
    if data[0]=='?':
        data[0] =''
    if data[1]=='?':
        data[1] =''
    if data[2]=='?':
        data[2] =''
    if data[3]=='?':
        data[3] =''
    n = "select * from room where (房间号=? or ?='') and (房型=? or ?='') and (单价=? or ?='') and (有无=? or ?='')"
    cur.execute(n, (data[0],data[0],data[1],data[1],data[2],data[2],data[3],data[3]))
    a = cur.fetchall()
    con.commit()
    con.close()
    return a

